@extends('layouts.admin.app')
@section('content')
<main>
    <div class="container-fluid site-width">
        <!-- START: Breadcrumbs-->
        <div class="row ">
            <div class="col-12  align-self-center">
                <div class="sub-header mt-3 py-3 align-self-center d-sm-flex w-100 rounded">
                    <div class="w-sm-100 mr-auto"><h4 class="mb-0 tc">{!! str_replace('-', ' ', $covid[0]->title) !!}</h4></div>

                    <ol class="breadcrumb bg-transparent align-self-center m-0 p-0">
                        <li class="breadcrumb-item">Home</li>
                        <li class="breadcrumb-item active"><a href="#">{{$covid[0]->title}}</a></li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- END: Breadcrumbs-->

        <div id="cmn-respns"></div>

        <!-- START: Card Data-->
        <div class="row">
            <div class="col-12 col-lg-12 mt-12">
                <div class="card">
                    <div class="card-header">                               
                        <h4 class="card-title">Page Elements</h4>                                
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <div class="row">                                           
                                <div class="col-12">
                                    @if(session()->has('message'))
                                        <div class="alert alert-success alert-dismissible fade show" role="alert"><strong>Success!</strong> Details Update Successfull.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                    @endif

                                    <form method="POST" action="/cms_triveni/public/admin/backgroud_image/edit/{{$covid[0]->id}}" enctype="multipart/form-data">@csrf
                                        <div class="form-group row" style="display:none;">
                                            <label for="username" class="col-sm-2 col-form-label">Title</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" name="title" id="title" placeholder="Title" value="{{$covid[0]->title}}" >
                                            </div>
                                        </div>
                                        <div class="form-group row" >
                                            <label for="username" class="col-sm-2 col-form-label">Class</label>
                                            <div class="col-sm-10">
                                                <input type="text" class="form-control" name="class" id="class" placeholder="Class" value="{{$covid[0]->class}}" >
                                            </div>
                                        </div>
                                        
                                          
                                       
                                       
                                        <?php
                            
                                            if($covid[0]->image=="" && $covid[0]->image_mobile==""){
                                                $style="display:none;";
                                            }else{
                                                $style="display:block;";
                                            }
                                        ?>    
                                        <div class="form-group row" style="{{$style}}">
                                            <label for="text" class="col-sm-2 col-form-label">Image Text</label>
                                            <div class="col-sm-10">
                                                <textarea name="image_text" id="image_text" class="summernote-cstm" placeholder="(optional)">{{$covid[0]->image_text}}</textarea>
                                            </div>
                                        </div>  
                                        <input type="hidden" name="cert_id" id="page_id" value="{{$covid[0]->id}}">
                                        <div class="form-group row">
                                            <div class="col-sm-10">
                                                <input type="submit" class="btn btn-primary" value="submit">  
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            
                            <div class="card-body" style="{{$style}}">
                                <div class="row"> 
                                    <div class="col-12">
                                        <form method="POST" id="background_edit" action="/cms_triveni/public/admin/backgroud_image/edit/{{$covid[0]->id}}" enctype="multipart/form-data">@csrf
                                            <div class="form-group row">
                                            <label for="inputPassword3" class="col-sm-2 col-form-label">Image</label>
                                            <div class="col-sm-10">
                                                <img src="">
                                                <iframe src="https://demo.sureshramesh.com/triveni_uploads/backgroud-image/{{$covid[0]->image}}" style="width: 40%;height: 60%;border: none;"></iframe>
                                                <h6>Dimensions : {{$covid[0]->desktop_dim}}</h6>
                                                <input type="file" name="file_banner" id="file_banner" class="form-control" id="file">
                                            </div>
                                        </div> 
                                        
                                        <div class="form-group row">
                                            <label for="inputPassword3" class="col-sm-2 col-form-label">Image Mobile</label>
                                            <div class="col-sm-10">
                                                <img src="">
                                                <iframe src="https://demo.sureshramesh.com/triveni_uploads/backgroud-image/mobile/{{$covid[0]->image_mobile}}" style="width: 40%;height: 60%;border: none;"></iframe>
                                                <h6>Dimensions : {{$covid[0]->mobile_dim}}</h6>
                                                <input type="file" name="file_banner_mobile" id="file_banner_mobile" class="form-control" id="file">
                                            </div>
                                        </div> 
                                        
                                                                           
                                            <div class="progress">
                                                <div class="bar"></div >
                                                <div class="percent">0%</div >
                                            </div><br>
                                            <input type="hidden" name="cert_id" id="cert_id" value="{{$covid[0]->id}}">
                                            <div class="form-group row">
                                                <div class="col-sm-10">
                                                <button type="submit" class="btn btn-primary">Upload File</button>  
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
                </div>
            </div>
        </div>
        <!-- END: Card DATA-->
    </div>
</main>

@endsection